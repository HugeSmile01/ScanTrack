function toggleMenu() {
  const menu = document.querySelector('.navbar nav ul.mobile-menu');
  menu.classList.toggle('active');
}